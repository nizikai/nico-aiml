import SwiftUI

@main
struct MyApp: App {
    var body: some Scene {
        WindowGroup {
//            SummaryView()
//            ARView()
//            EndingView()
//            GuideView()
            WelcomeView(scene: WelcomeScene(), routes: NavigationPath())
                .preferredColorScheme(.dark)
        }
    }
}
