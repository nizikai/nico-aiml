//
//  GuideView.swift
//  Unconfined
//
//  Created by Nico Prasetyo on 24/02/24.
//

import SwiftUI
import AVFoundation

struct GuideView: View {
    @State var isVisible: Bool = false
    @State var changeView: Bool = false
    
    @AccessibilityFocusState var announce1: Bool
    @AccessibilityFocusState var announce2: Bool
    @AccessibilityFocusState var announce3: Bool
    @AccessibilityFocusState var announce4: Bool
    @AccessibilityFocusState var announce5: Bool
    @AccessibilityFocusState var announce6: Bool
    @AccessibilityFocusState var announce7: Bool
    @AccessibilityFocusState var announce8: Bool
    
    var audioPlayer = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "Demo", withExtension: "mp3")!)
    
    
    var body: some View {
        ZStack{
            Image("whiteSparks")
                .opacity(isVisible ? 0.3 : 0)
                .accessibilityHidden(true)
            
            VStack{
                Spacer()
                
                Text("The Coins are now confined to darkness.")
                    .font(.title)
                    .fontWeight(.semibold)
                    .foregroundStyle(.white)
                    .multilineTextAlignment(.center)
                    .shadow(color: .white, radius: 1)
                    .padding()
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .accessibilitySortPriority(9)
                    .accessibilityFocused($announce1)
                    .onAppear(){
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            announce1 = true
                        }
                    }
                
                Text("But, they will resonate to a specific sound you make.\nSuch as, a tongue click sound, which enables us to locate them.")
                    .accessibilitySortPriority(8)
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundStyle(.white)
                    .multilineTextAlignment(.center)
                    .shadow(color: .white, radius: 1)
                    .padding()
                    .accessibilityFocused($announce2)
                    .onAppear(){
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            announce2 = true
                        }
                    }
                
                Text("To produce the tongue click sound, you need to:")
                    .accessibilitySortPriority(7)
                    .foregroundStyle(.white)
                    .multilineTextAlignment(.center)
                    .padding()
                    .accessibilityFocused($announce3)
                    .onAppear(){
                        announce3 = false
                    }
                
                Text("Place your tongue on the roof of your mouth.")
                    .accessibilitySortPriority(6)
                    .font(.headline)
                    .fontWeight(.regular)
                    .foregroundStyle(.white)
                    .multilineTextAlignment(.center)
                    .shadow(color: .white, radius: 1)
                    .padding()
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .accessibilityFocused($announce4)
                    .onAppear(){
                        announce4 = false
                    }
                
                Text("Then, create suction with your tongue by sucking in.")
                    .accessibilitySortPriority(5)
                    .font(.headline)
                    .fontWeight(.regular)
                    .foregroundStyle(.white)
                    .multilineTextAlignment(.center)
                    .shadow(color: .white, radius: 1)
                    .padding()
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .accessibilityFocused($announce5)
                    .onAppear(){
                        announce5 = false
                    }
                
                Text("Finally, quickly release by pulling your tongue down.")
                    .accessibilitySortPriority(4)
                    .font(.headline)
                    .fontWeight(.regular)
                    .foregroundStyle(.white)
                    .multilineTextAlignment(.center)
                    .shadow(color: .white, radius: 1)
                    .padding()
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .accessibilityFocused($announce6)
                    .onAppear(){
                        announce6 = false
                    }
                VStack{}
                    .frame(height: 64)
                
                VStack{
                    HStack{
                        
                        Button(action: {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                audioPlayer.play()
                            }
                        }, label: {
                            Text("Play Tongue Click Sound")
                                .accessibilityLabel("Play Tounge Click Example Sound")
                                .fontWeight(.regular)
                                .foregroundStyle(.black)
                                .frame(width: 256, height: 40)
                                .accessibilitySortPriority(3)
                                .background(RoundedRectangle(cornerRadius: 10).fill(Color(.white)).shadow(color: .white, radius: 7))
                                .accessibilityFocused($announce7)
                                .onAppear(){
                                    announce7 = false
                                }
                        })
                        .padding(.top, 24)
                        HStack{}.frame(width: 8)
                        Button(action: {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                withAnimation(.easeIn(duration: 0.3)){
                                    isVisible = false
                                }
                            }
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                                changeView = true
                            }
                        }, label: {
                            Text("Enter Realm")
                                .accessibilityLabel("You're entering the Augmented Reality Realm. Just hold your device and face its back camera anywhere to hear the coins' resonance from your sound. Tap to Enter Realm")
                                .font(.headline)
                                .fontWeight(.bold)
                                .foregroundStyle(.black)
                                .frame(width: 144, height: 40)
                                .accessibilitySortPriority(6)
                                .background(RoundedRectangle(cornerRadius: 10).fill(Color(.white)).shadow(color: .white, radius: 7))
                                .accessibilitySortPriority(1)
                                .accessibilityFocused($announce7)
                                .onAppear(){
                                    announce7 = false
                                }
                        })
                        .padding(.top, 24)
                    }
                    
                    Text("You're entering the Augmented Reality Realm. \nJust hold your device and face its back camera anywhere \nto hear the coins' resonance from your sound.")
                        .accessibilityHidden(true)
                        .foregroundStyle(.white)
                        .multilineTextAlignment(.center)
                        .padding(.bottom, 8)
                        .padding(.top, 16)
                        .padding(.trailing, 16)
                        .padding(.leading, 16)
                }
                
                Spacer()
                
            }
            .opacity(isVisible ? 1 : 0)
        }
        .navigationBarBackButtonHidden()
        .onAppear(){
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                withAnimation(.easeIn(duration: 0.5)){
                    isVisible = true
                }
            }
        }
        .navigationDestination(isPresented: $changeView) {
            ARView()
        }
    }
}

#Preview {
    GuideView()
}
