import SwiftUI
import SpriteKit
import AVFoundation

class EndingScene: SKScene, ObservableObject{
    @Published var soundRecognized: Bool = false
    
    let redRing = SKSpriteNode(imageNamed: "redRing")
    let greenRing = SKSpriteNode(imageNamed: "greenRing")
    let blueRing = SKSpriteNode(imageNamed: "blueRing")
    let whiteBlob = SKSpriteNode(imageNamed: "whiteBlob")
    let whiteSpark = SKSpriteNode(imageNamed: "whiteSparks")
    
    let lightNodeRed = SKLightNode()
    let lightNodeGreen = SKLightNode()
    let lightNodeBlue = SKLightNode()
    
    let whiteLine = SKSpriteNode(imageNamed: "whiteLine")
    let glowLine = SKSpriteNode(imageNamed: "glowLine")
    let line1 = SKSpriteNode(imageNamed: "lineOne")
    let line2 = SKSpriteNode(imageNamed: "lineOne")
    let line3 = SKSpriteNode(imageNamed: "lineTwo")
    let line4 = SKSpriteNode(imageNamed: "lineOne")
    let line5 = SKSpriteNode(imageNamed: "lineOne")
    let line6 = SKSpriteNode(imageNamed: "lineTwo")
    let line7 = SKSpriteNode(imageNamed: "lineThree")
    let line8 = SKSpriteNode(imageNamed: "lineFive")
    let line9 = SKSpriteNode(imageNamed: "lineFour")
    let line10 = SKSpriteNode(imageNamed: "lineFive")
    let line11 = SKSpriteNode(imageNamed: "lineThree")
    let line12 = SKSpriteNode(imageNamed: "lineFour")
    let line13 = SKSpriteNode(imageNamed: "lineThree")
    let line14 = SKSpriteNode(imageNamed: "lineFour")
    let line15 = SKSpriteNode(imageNamed: "lineOne")
    let line16 = SKSpriteNode(imageNamed: "lineThree")
    let line17 = SKSpriteNode(imageNamed: "lineOne")
    let line18 = SKSpriteNode(imageNamed: "lineTwo")
    let line19 = SKSpriteNode(imageNamed: "lineOne")
    let line20 = SKSpriteNode(imageNamed: "lineOne")
    
    override func didMove(to view: SKView) {
        
        scene?.size = CGSize(width: 2160, height: 1620)
        scene?.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        scene?.backgroundColor = UIColor(.black)
        scene?.view?.allowsTransparency = true
        scene?.scaleMode = .aspectFill
        
        redRing.position = CGPoint(x: 400, y: -200)
        redRing.size = CGSize(width: 500, height: 500)
        redRing.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        redRing.lightingBitMask = 1
        redRing.alpha = 0
        self.addChild(redRing)
        
        whiteBlob.position = CGPoint(x: 0, y: 0)
        whiteBlob.size = CGSize(width: 750, height: 750)
        whiteBlob.setScale(0)
        whiteBlob.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        whiteBlob.lightingBitMask = 1
        whiteBlob.blendMode = SKBlendMode.screen
        self.addChild(whiteBlob)
        
        lightNodeRed.falloff = 1
        lightNodeRed.ambientColor = .white
        lightNodeRed.lightColor = .white
        lightNodeRed.categoryBitMask = 1
        lightNodeRed.alpha = 0
        lightNodeRed.position = CGPoint(x: 0, y: 0)
        redRing.addChild(lightNodeRed)
        
        blueRing.position = CGPoint(x: -200, y: 300)
        blueRing.size = CGSize(width: 300, height: 300)
        blueRing.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        blueRing.zRotation = 272
        blueRing.lightingBitMask = 1
        blueRing.alpha = 0
        self.addChild(blueRing)
        
        lightNodeBlue.falloff = 1
        lightNodeBlue.ambientColor = .white
        lightNodeBlue.lightColor = .white
        lightNodeBlue.categoryBitMask = 1
        lightNodeBlue.alpha = 0
        lightNodeBlue.position = CGPoint(x: 0, y: 0)
        blueRing.addChild(lightNodeBlue)
        
        greenRing.position = CGPoint(x: -400, y: -400)
        greenRing.size = CGSize(width: 750, height: 750)
        greenRing.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        greenRing.lightingBitMask = 1
        greenRing.alpha = 0
        self.addChild(greenRing)
        
        lightNodeGreen.falloff = 1
        lightNodeGreen.ambientColor = .white
        lightNodeGreen.lightColor = .white
        lightNodeGreen.categoryBitMask = 1
        lightNodeGreen.alpha = 0
        lightNodeGreen.position = CGPoint(x: -1000, y: -1000)
        greenRing.addChild(lightNodeGreen)
        
        whiteLine.position = CGPoint(x: 0, y: 0)
        whiteLine.size = CGSize(width: 1500, height: 1500)
        whiteLine.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        whiteLine.lightingBitMask = 1
        whiteLine.alpha = 0
        whiteLine.blendMode = SKBlendMode.screen
        self.addChild(whiteLine)
        
        line1.position = CGPoint(x: -500, y: 0)
        line1.size = CGSize(width: 80, height: 300)
        line1.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line1.lightingBitMask = 1
        line1.alpha = 0
        line1.blendMode = SKBlendMode.screen
        self.addChild(line1)
        
        line2.position = CGPoint(x: -450, y: 0)
        line2.size = CGSize(width: 80, height: 300)
        line2.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line2.lightingBitMask = 1
        line2.alpha = 0
        line2.blendMode = SKBlendMode.screen
        self.addChild(line2)
        
        line3.position = CGPoint(x: -400, y: 0)
        line2.size = CGSize(width: 80, height: 300)
        line3.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line3.lightingBitMask = 1
        line3.alpha = 0
        line3.blendMode = SKBlendMode.screen
        self.addChild(line3)
        
        line4.position = CGPoint(x: -350, y: 0)
        line4.size = CGSize(width: 80, height: 300)
        line4.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line4.lightingBitMask = 1
        line4.alpha = 0
        line4.blendMode = SKBlendMode.screen
        self.addChild(line4)
        
        line5.position = CGPoint(x: -300, y: 0)
        line5.size = CGSize(width: 80, height: 300)
        line5.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line5.lightingBitMask = 1
        line5.alpha = 0
        line5.blendMode = SKBlendMode.screen
        self.addChild(line5)
        
        line6.position = CGPoint(x: -250, y: 0)
        line6.size = CGSize(width: 80, height: 300)
        line6.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line6.lightingBitMask = 1
        line6.alpha = 0
        line6.blendMode = SKBlendMode.screen
        self.addChild(line6)
        
        line7.position = CGPoint(x: -200, y: 0)
        line7.size = CGSize(width: 80, height: 300)
        line7.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line7.lightingBitMask = 1
        line7.alpha = 0
        line7.blendMode = SKBlendMode.screen
        self.addChild(line7)
        
        line8.position = CGPoint(x: -150, y: 0)
        line8.size = CGSize(width: 80, height: 300)
        line8.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line8.lightingBitMask = 1
        line8.alpha = 0
        line8.blendMode = SKBlendMode.screen
        self.addChild(line8)
        
        line9.position = CGPoint(x: -100, y: 0)
        line9.size = CGSize(width: 80, height: 300)
        line9.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line9.lightingBitMask = 1
        line9.alpha = 0
        line9.blendMode = SKBlendMode.screen
        self.addChild(line9)
        
        line10.position = CGPoint(x: -50, y: 0)
        line10.size = CGSize(width: 80, height: 300)
        line10.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line10.lightingBitMask = 1
        line10.alpha = 0
        line10.blendMode = SKBlendMode.screen
        self.addChild(line10)
        
        line11.position = CGPoint(x: 0, y: 0)
        line11.size = CGSize(width: 80, height: 300)
        line11.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line11.lightingBitMask = 1
        line11.alpha = 0
        line11.blendMode = SKBlendMode.screen
        self.addChild(line11)
        
        line12.position = CGPoint(x: 50, y: 0)
        line12.size = CGSize(width: 80, height: 300)
        line12.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line12.lightingBitMask = 1
        line12.alpha = 0
        line12.blendMode = SKBlendMode.screen
        self.addChild(line12)
        
        line13.position = CGPoint(x: 100, y: 0)
        line13.size = CGSize(width: 80, height: 300)
        line13.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line13.lightingBitMask = 1
        line13.alpha = 0
        line13.blendMode = SKBlendMode.screen
        self.addChild(line13)
        
        line14.position = CGPoint(x: 150, y: 0)
        line14.size = CGSize(width: 80, height: 300)
        line14.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line14.lightingBitMask = 1
        line14.alpha = 0
        line14.blendMode = SKBlendMode.screen
        self.addChild(line14)
        
        line15.position = CGPoint(x: 200, y: 0)
        line15.size = CGSize(width: 80, height: 300)
        line15.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line15.lightingBitMask = 1
        line15.alpha = 0
        line15.blendMode = SKBlendMode.screen
        self.addChild(line15)
        
        line16.position = CGPoint(x: 250, y: 0)
        line16.size = CGSize(width: 80, height: 300)
        line16.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line16.lightingBitMask = 1
        line16.alpha = 0
        line16.blendMode = SKBlendMode.screen
        self.addChild(line16)
        
        line17.position = CGPoint(x: 300, y: 0)
        line17.size = CGSize(width: 80, height: 300)
        line17.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line17.lightingBitMask = 1
        line17.alpha = 0
        line17.blendMode = SKBlendMode.screen
        self.addChild(line17)
        
        line18.position = CGPoint(x: 350, y: 0)
        line18.size = CGSize(width: 80, height: 300)
        line18.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line18.lightingBitMask = 1
        line18.alpha = 0
        line18.blendMode = SKBlendMode.screen
        self.addChild(line18)
        
        line19.position = CGPoint(x: 400, y: 0)
        line19.size = CGSize(width: 80, height: 300)
        line19.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line19.lightingBitMask = 1
        line19.alpha = 0
        line19.blendMode = SKBlendMode.screen
        self.addChild(line19)
        
        line20.position = CGPoint(x: 450, y: 0)
        line20.size = CGSize(width: 80, height: 300)
        line20.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line20.lightingBitMask = 1
        line20.alpha = 0
        line20.blendMode = SKBlendMode.screen
        self.addChild(line20)
    }
    
    override func update(_ currentTime: TimeInterval) {
        let emerge = SKAction.fadeAlpha(by: 1, duration: 0.5)
        let appear = SKAction.fadeAlpha(by: 1, duration: 0.2)
        let rotateAction = SKAction.rotate(byAngle: 2 * Double.pi, duration: 10)
        let rotateForever = SKAction.repeatForever(rotateAction)
        let scaleZero = SKAction.scale(to: 0, duration: 0.7)
        let scaleFull = SKAction.scale(to: 10, duration: 0.4)
        let moveToCentre = SKAction.move(to: CGPoint(x: 0, y: 0), duration: 1)
        
        let wait3 = SKAction.wait(forDuration: 3)
        
        scaleFull.timingMode = .easeInEaseOut
        
        whiteLine.run(emerge){
            self.redRing.run(emerge)
            self.greenRing.run(emerge)
            self.blueRing.run(emerge)
        }
        
        if soundRecognized{
            self.blueRing.run(wait3){
                self.blueRing.run(rotateForever)
                self.lightNodeBlue.run(emerge)
                self.redRing.run(wait3){
                    self.redRing.run(rotateForever)
                    self.lightNodeRed.run(emerge)
                    self.greenRing.run(wait3){
                        self.lightNodeGreen.run(emerge)
                        self.greenRing.run(rotateForever)
                        self.greenRing.run(wait3){
                            self.redRing.run(moveToCentre)
                            self.redRing.run(scaleZero)
                            self.greenRing.run(moveToCentre)
                            self.greenRing.run(scaleZero)
                            self.blueRing.run(moveToCentre)
                            self.blueRing.run(scaleZero)
                            
                            self.line10.run(appear)
                            self.line11.run(appear){
                                self.line12.run(appear)
                                self.line9.run(appear){
                                    self.line13.run(appear)
                                    self.line8.run(appear){
                                        self.whiteSpark.run(emerge)
                                        self.line14.run(appear)
                                        self.line7.run(appear){
                                            self.glowLine.run(emerge)
                                            self.line15.run(appear)
                                            self.line6.run(appear){
                                                self.line16.run(appear)
                                                self.line5.run(appear){
                                                    self.line17.run(appear)
                                                    self.line4.run(appear){
                                                        self.line18.run(appear)
                                                        self.line3.run(appear){
                                                            self.line19.run(appear)
                                                            self.line2.run(appear){
                                                                self.line10.run(appear)
                                                                self.line11.run(appear)
                                                                self.whiteBlob.run(appear)
                                                                self.whiteBlob.run(scaleFull)
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        }
                    }
                }
            }
        }
    }
    
    
    struct EndingView: View {
        @State var isVisible: Bool = false
        @ObservedObject var scene: EndingScene
        
        private var streamManager: AudioStreamManager
        @ObservedObject var observer: AudioStreamObserver
        
        @State var showCaption2: Bool = false
        @State var showCaption3: Bool = false
        @State var showCaption4: Bool = false
        @State var showCaption5: Bool = false
        @State var showCaption6: Bool = false
        @State var hideAll: Bool = false
        @State var changeView: Bool = false
        
        @State var counter = 0
        
        var audioPlayer1 = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "Ending", withExtension: "mp3")!)
        var audioPlayer2 = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "Captured", withExtension: "mp3")!)
        
        init() {
            scene = EndingScene()
            observer = AudioStreamObserver()
            streamManager = AudioStreamManager()
            streamManager.startAudioAnalyzer(with: observer)
        }
        
        var body: some View {
            ZStack{
                
                SpriteView(scene: scene, preferredFramesPerSecond: 60)
                    .ignoresSafeArea()
                
                if(hideAll == false){
                    Text("You are the light.")
                        .opacity(showCaption6 ? 1 : 0)
                        .fontWeight(.bold)
                        .foregroundStyle(.black)
                        .italic()
                        .font(.title)
                        .accessibilityHidden(true)
                    
                    VStack{
                        Spacer()
                        if(scene.soundRecognized){
                            Text(showCaption6 ? "You are the light" : showCaption5 ? "You have restored the light of this realm.." : showCaption4 ? "Red resonates courage and Green resonates humility." : showCaption3 ? "Blue Chroma Coin resonate confidence" : showCaption2 ? "Where there was darkness.." : "A new String of Resonance is here.")
                                .font(.body)
                                .fontWeight(.semibold)
                                .foregroundStyle(.white)
                                .shadow(color: .white, radius: 1)
                                .padding()
                                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                                .accessibilityHidden(true)
                                .onAppear(){
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0) {
                                        audioPlayer2.setVolume(0.5, fadeDuration: 1)
                                        audioPlayer2.play()
                                    }
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                        audioPlayer1.setVolume(0.4, fadeDuration: 2.5)
                                        audioPlayer1.play()
                                    }
                                    
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                                        showCaption2 = true
                                    }
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 5.5) {
                                        showCaption3 = true
                                    }
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 9.5) {
                                        showCaption4 = true
                                    }
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 14) {
                                        showCaption5 = true
                                    }
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 15.5) {
                                        withAnimation(.easeIn(duration: 0.5)){
                                            showCaption6 = true
                                        }
                                    }
                                    
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 19.5) {
                                        withAnimation(.easeIn(duration: 0.5)){
                                            hideAll = true
                                            changeView = true
                                        }
                                    }
                                }
                            
                        }else{
                            Text("You've captured all the Chroma Coins! Now all we need is a new String of Resonance.\nWe need you to do one last tongue click sound please.")
                                .font(.body)
                                .fontWeight(.semibold)
                                .foregroundStyle(.white)
                                .multilineTextAlignment(.center)
                                .shadow(color: .white, radius: 1)
                                .padding()
                                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                                .opacity(isVisible ? 1 : 0)
                        }
                        
                        VStack{}
                            .padding(.top, 16)
                            .onReceive(observer.$latestSound) { latestSound in
                                if observer.latestSound == "Clicks" || observer.latestSound == "Mushy Clicks" {
                                    counter += 1
                                    print("sound recognized")
                                    if (counter > 2) {
                                        withAnimation(.easeIn(duration: 0.5)){
                                            scene.soundRecognized = true
                                        }
                                    }
                                }
                            }
                    }
                }
            }
            .opacity(isVisible ? 1 : 0)
            .onAppear(){
                DispatchQueue.main.asyncAfter(deadline: .now() + 8) {
                    streamManager.installAudioTap()
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    withAnimation(.easeIn(duration: 0.5)){
                        isVisible = true
                    }
                }
            }
            .navigationBarBackButtonHidden()
            .navigationDestination(isPresented: $changeView) {
                SummaryView()
            }
        }
        
    }
    
    
    
