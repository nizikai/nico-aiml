//To open the eyes that are blind, to bring out the prisoners from the dungeon, from the prison those who sit in darkness.

import SwiftUI
import CoreMotion
import SpriteKit
import AVFoundation

class WelcomeScene: SKScene, ObservableObject {
    
    @ObservedObject var motion = MotionData()
    @Published var startTapped: Bool = false
    
//    func spriteParallax(multiplierX: Float, multiplierY: Float) -> CGPoint{
//        let deviceOrientation = UIDevice.current.orientation.rawValue
//        
//        motion.getMotionData()
//        
//        switch deviceOrientation{
//        case 1:
//            return CGPoint(x: remainder(motion.roll, 3) * Double(multiplierX), y: remainder(motion.pitch, 3) * Double(multiplierY))
//        case 2:
//            return CGPoint(x: remainder(motion.roll, 3) * Double(multiplierX), y: remainder(motion.pitch, 3) * Double(multiplierY) * -1)
//        case 3:
//            return CGPoint(x: remainder(motion.yaw, 3) * Double(multiplierX) * -1, y: remainder(motion.roll, 3) * Double(multiplierY) * -1)
//        case 4:
//            return CGPoint(x: remainder(motion.yaw, 3) * Double(multiplierX) * -1, y: remainder(motion.roll, 3) * Double(multiplierY))
//        default:
//            return CGPoint(x: remainder(motion.yaw, 3) * Double(multiplierX), y: remainder(motion.roll, 3) * Double(multiplierY))
//        }
//    }
    
    let blueCircleNode = SKSpriteNode(imageNamed: "blueCircle")
    let redCircleNode = SKSpriteNode(imageNamed: "redCircle")
    let greenCircleNode = SKSpriteNode(imageNamed: "greenCircle")
    let whiteBlobNode = SKSpriteNode(imageNamed: "whiteBlob")
    let whiteSparks = SKSpriteNode(imageNamed: "whiteSparks")
    let blackNode = SKSpriteNode(imageNamed: "Black")
    
    let lightNode1 = SKLightNode()
    let lightNode2 = SKLightNode()
    let lightNode3 = SKLightNode()
    
    override func didMove(to view: SKView) {
        
        scene?.size = CGSize(width: 2160, height: 1620)
        scene?.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        scene?.backgroundColor = UIColor(.black)
        scene?.view?.allowsTransparency = true
        scene?.scaleMode = .aspectFill
        
        lightNode1.falloff = 3
        lightNode1.ambientColor = .white
        lightNode1.lightColor = .white
        lightNode1.categoryBitMask = 1
        lightNode1.position = CGPoint(x: 0, y: 800)
        self.addChild(lightNode1)
        
        lightNode2.falloff = 3
        lightNode2.ambientColor = .white
        lightNode2.lightColor = .white
        lightNode2.categoryBitMask = 1
        lightNode2.position = CGPoint(x: -800, y: -700)
        self.addChild(lightNode2)
        
        lightNode3.falloff = 0
        lightNode3.ambientColor = .white
        lightNode3.lightColor = .white
        lightNode3.categoryBitMask = 1
        lightNode3.position = CGPoint(x: 800, y: -700)
        self.addChild(lightNode3)
        
        whiteSparks.position = CGPoint(x: 0, y: 0)
        whiteSparks.size = CGSize(width: 1000, height: 1000)
        whiteSparks.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        whiteSparks.lightingBitMask = 1
        whiteSparks.setScale(0)
        whiteSparks.blendMode = SKBlendMode.screen
        self.addChild(whiteSparks)
        
        blueCircleNode.position = CGPoint(x: 0, y: 254)
        blueCircleNode.size = CGSize(width: 750, height: 750)
        blueCircleNode.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        blueCircleNode.lightingBitMask = 1
        blueCircleNode.blendMode = SKBlendMode.screen
        self.addChild(blueCircleNode)
        
        redCircleNode.position = CGPoint(x: -228, y: -137)
        redCircleNode.size = CGSize(width: 750, height: 750)
        redCircleNode.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        redCircleNode.lightingBitMask = 1
        redCircleNode.blendMode = SKBlendMode.screen
        self.addChild(redCircleNode)
        
        greenCircleNode.position = CGPoint(x: 220, y: -137)
        greenCircleNode.size = CGSize(width: 750, height: 750)
        greenCircleNode.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        greenCircleNode.lightingBitMask = 1
        greenCircleNode.blendMode = SKBlendMode.screen
        self.addChild(greenCircleNode)
        
        whiteBlobNode.position = CGPoint(x: 0, y: 0)
        whiteBlobNode.size = CGSize(width: 750, height: 750)
        whiteBlobNode.setScale(0)
        whiteBlobNode.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        whiteBlobNode.lightingBitMask = 1
        whiteBlobNode.blendMode = SKBlendMode.screen
        self.addChild(whiteBlobNode)
        
        blackNode.position = CGPoint(x: 0, y: 0)
        blackNode.size = CGSize(width: 5000, height: 5000)
        blackNode.alpha = 0
        blackNode.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        self.addChild(blackNode)
        
    }
    
    override func update(_ currentTime: TimeInterval) {
        
        //Add parallax
        //        scene?.anchorPoint = spriteParallax(multiplierX: 1, multiplierY: 1)
//        redCircleNode.position = spriteParallax(multiplierX: 10, multiplierY: 10)
        
        if startTapped{
            
            let rotateAction1 = SKAction.rotate(byAngle: 2 * Double.pi, duration: 1)
            let rotateAction2 = SKAction.rotate(byAngle: 2 * Double.pi, duration: 0.5)
            let rotateAction3 = SKAction.rotate(byAngle: 2 * Double.pi, duration: 0.0006)
            let accelerationSequence = SKAction.sequence([rotateAction3, rotateAction2, rotateAction1, SKAction.repeatForever(rotateAction1)])
            
            let fadeOut = SKAction.fadeAlpha(to: 1, duration: 0.2)
            
            let moveRed = SKAction.move(to: CGPoint(x: -528, y: -437), duration: 0.5)
            let moveBlue = SKAction.move(to: CGPoint(x: 0, y: 554), duration: 0.5)
            let moveGreen = SKAction.move(to: CGPoint(x: 520, y: -437), duration: 0.5)
            let moveToCentreAction = SKAction.move(to: CGPoint(x: 0, y: 0), duration: 0.1)
            
            let scaleUp = SKAction.scale(to: 0.8, duration: 0.5)
            let scaleDown = SKAction.scale(to: 0.2, duration: 0.2)
            let scaleFull = SKAction.scale(to: 15, duration: 0.5)
            let scaleFull2 = SKAction.scale(to: 15, duration: 2)
            
            let wait = SKAction.wait(forDuration: 0.7)
            
            let whiteBlobAppear = SKAction.sequence([wait, scaleUp, wait])
            
            moveRed.timingMode = .easeInEaseOut
            moveGreen.timingMode = .easeInEaseOut
            moveBlue.timingMode = .easeInEaseOut
            accelerationSequence.timingMode = .easeIn
            moveToCentreAction.timingMode = .easeInEaseOut
            scaleUp.timingMode = .easeInEaseOut
            scaleDown.timingMode = .easeOut
            scaleFull.timingMode = .easeOut
            scaleFull2.timingMode = .easeOut
            
            whiteSparks.run(scaleFull2)
            
            redCircleNode.run(moveRed){
                self.redCircleNode.run(accelerationSequence)
                self.redCircleNode.run(moveToCentreAction)
            }
            greenCircleNode.run(moveGreen){
                self.greenCircleNode.run(accelerationSequence)
                self.greenCircleNode.run(moveToCentreAction)
            }
            blueCircleNode.run(moveBlue){
                self.blueCircleNode.run(accelerationSequence)
                self.blueCircleNode.run(moveToCentreAction)
            }
            
            whiteBlobNode.run(whiteBlobAppear){
                self.whiteBlobNode.run(scaleDown){
                    self.whiteBlobNode.run(scaleFull)
                    {
                        self.blackNode.run(fadeOut)
                    }
                }
            }
            
            //Move Lights to Centre
            lightNode1.run(moveToCentreAction)
            lightNode2.run(moveToCentreAction)
            lightNode3.run(moveToCentreAction)
        }
    }
}

struct WelcomeView: View {
    
    @ObservedObject var scene: WelcomeScene
    @ObservedObject var motion = MotionData()
    @State var changeView: Bool = false
    @State var isHidden: Bool = false
    @State var routes: NavigationPath
    
    var audioPlayer = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "Boom", withExtension: "mp3")!)
    
    @AccessibilityFocusState var announce1: Bool
    @AccessibilityFocusState var announce2: Bool
    @AccessibilityFocusState var announce3: Bool
    @AccessibilityFocusState var announce4: Bool
    @AccessibilityFocusState var announce5: Bool
    
//    func swiftParallax(multiplier: Float) -> CGSize{
//        let deviceOrientation = UIDevice.current.orientation.rawValue
//        
//        switch deviceOrientation{
//        case 1:
//            return CGSize(width: motion.roll * Double(multiplier), height: motion.pitch * Double(multiplier) * -1)
//        case 2:
//            return CGSize(width: motion.roll * Double(multiplier), height: motion.pitch * Double(multiplier))
//        case 3:
//            return CGSize(width: motion.yaw * Double(multiplier), height: motion.roll * Double(multiplier))
//        case 4:
//            return CGSize(width: motion.yaw * Double(multiplier) * -1, height: motion.roll * Double(multiplier) * -1)
//        default:
//            return CGSize(width: motion.yaw * Double(multiplier), height: motion.roll * Double(multiplier))
//        }
//    }
    
    var body: some View {
        
        NavigationStack(path: $routes){
            
            ZStack{
                
                SpriteView(scene: scene, preferredFramesPerSecond: 60)
                    .ignoresSafeArea()
                    .accessibilityLabel("Three coins of Red, Green, and Blue.")
                
                VStack{
                    VStack{}
                        .frame(height: 32)
                    
                    Text("Welcome to Unconfined")
                        .font(.title)
                        .fontWeight(.semibold)
                        .foregroundStyle(.white)
                        .shadow(color: .white, radius: 1)
                        .padding()
                        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                        .accessibilitySortPriority(4)
                        .accessibilityFocused($announce1)
                    
                    Spacer()
                    
                    ZStack{
                        VStack{
                            Text("Earphones are essential to fully\nexperience this app.")
                                .foregroundStyle(.white)
                                .multilineTextAlignment(.center)
                                .opacity(0.8)
                                .padding(.bottom, 8)
                                .padding(.top, 16)
                                .padding(.trailing, 16)
                                .padding(.leading, 16)
                                .accessibilitySortPriority(2)
                                .accessibilityFocused($announce3)
                                .onAppear(){
                                    announce3 = false
                                }
                            Button(action: {
                                audioPlayer.setVolume(0.7, fadeDuration: 1)
                                audioPlayer.play()
                                scene.startTapped = true
                                withAnimation(.easeIn(duration: 1.5)){
                                    isHidden = true
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                                    changeView = true
                                }
                            }, label: {
                                Text("Continue")
                                    .font(.headline)
                                    .fontWeight(.bold)
                                    .foregroundStyle(.black)
                                    .frame(width: 144, height: 40)
                                    .accessibilitySortPriority(1)
                                    .background(RoundedRectangle(cornerRadius: 10).fill(Color(.white)).shadow(color: .white, radius: 7))
                                    .accessibilityFocused($announce4)
                                    .onAppear(){
                                        announce4 = false
                                    }
                            })
                        }
                    }
                    .accessibilitySortPriority(1)
                    .padding(.bottom,24)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    
                    Text("Unconfined is an app that teaches human echolocation basics throughout a story to enhance daily navigation for visually impaired individuals. Please use it in a quite environment.")
                        .foregroundStyle(.white)
                        .shadow(color: .white, radius: 1)
                        .font(.caption)
                        .multilineTextAlignment(.center)
                        .padding(.top, 16)
                        .padding(.bottom, 16)
                        .accessibilitySortPriority(3)
                        .accessibilityFocused($announce2)
                        .onAppear(){
                            announce1 = false
                        }
                }
                .opacity(isHidden ? 0.0 : 1.0)
                
            }
            .onAppear {
                announce1 = true
            }
            .navigationDestination(isPresented: $changeView) {
                StoryView(scene: StoryScene())
            }
        }
    }
}
