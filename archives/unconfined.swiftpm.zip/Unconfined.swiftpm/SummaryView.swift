import SwiftUI
import AVFoundation

struct SummaryView: View {
    @State var isVisible: Bool = false
    @State var changeView: Bool = false
    
    @AccessibilityFocusState var announce1: Bool
    @AccessibilityFocusState var announce2: Bool
    @AccessibilityFocusState var announce3: Bool
    @AccessibilityFocusState var announce4: Bool
    @AccessibilityFocusState var announce5: Bool
    @AccessibilityFocusState var announce6: Bool
    @AccessibilityFocusState var announce7: Bool
    @AccessibilityFocusState var announce8: Bool
    
        var audioPlayerFar = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "Far", withExtension: "mp3")!)
    
    var audioPlayerHalf = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "Half", withExtension: "mp3")!)
    
    var audioPlayerNear = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "Near", withExtension: "mp3")!)
    
    
    var body: some View {
        ZStack{
            Image("whiteBlob")
                .resizable()
                .opacity(isVisible ? 1 : 0)
                .frame(width: 4000, height: 4000)
                .accessibilityHidden(true)
                .ignoresSafeArea()
                
            VStack{
                Spacer()
                
                Text("This app simulates and teaches\nthe basics of Human Echolocation")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundStyle(.black)
                    .multilineTextAlignment(.center)
                    .shadow(color: .white, radius: 1)
                    .padding()
                    .accessibilitySortPriority(9)
                    .accessibilityFocused($announce1)
                    .onAppear(){
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            announce1 = true
                        }
                    }
                
                Text("It may take weeks to months to distinguish the sound feedback of objects in the real world.\nPracticing with a companion may aid in developing this echolocation skill.")
                    .accessibilitySortPriority(8)
                    .font(.headline)
                    .fontWeight(.semibold)
                    .foregroundStyle(.black)
                    .multilineTextAlignment(.center)
                    .shadow(color: .white, radius: 1)
                    .padding()
                    .accessibilityFocused($announce2)
                    .onAppear(){
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            announce2 = true
                        }
                    }
                
                Text("If there were significant reverberation in the sound,\nit would indicate that the object is farther away.\nTherefore, the absence of reverb implies that the object is nearby\nor in close proximity to your position.")
                    .accessibilitySortPriority(7)
                    .foregroundStyle(.black)
                    .multilineTextAlignment(.center)
                    .padding()
                    .accessibilityFocused($announce3)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .onAppear(){
                        announce3 = false
                    }
                
//                Text("Here are the sounds that were used to craft the experience.")
//                    .accessibilitySortPriority(6)
//                    .font(.headline)
//                    .fontWeight(.regular)
//                    .foregroundStyle(.black)
//                    .multilineTextAlignment(.center)
//                    .padding()
//                    .accessibilityFocused($announce4)
//                    .onAppear(){
//                        announce4 = false
//                    }
                
//                VStack{}
//                    .frame(height: 64)
                
//                VStack{
//                    HStack{
//                        Button(action: {
//                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
//                                audioPlayerNear.prepareToPlay()
//                                audioPlayerNear.play()
//                            }
//                        }, label: {
//                            Text("Nearby")
////                                .accessibilityLabel("Play the sound that simulates the clicking feedback of objects that are nearby.")
//                                .fontWeight(.regular)
//                                .foregroundStyle(.white)
//                                .frame(width: 176, height: 64)
//                                .accessibilitySortPriority(6)
//                                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
//                                .accessibilitySortPriority(3)
//                                .accessibilityFocused($announce5)
//                                .onAppear(){
//                                    announce5 = false
//                                }
//                        })
//                        
//                        HStack{}.frame(width: 8)
//                        Button(action: {
//                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
//                                audioPlayerHalf.prepareToPlay()
//                                audioPlayerHalf.play()
//                            }
//                            
//                        }, label: {
//                            Text("Medium")
////                                .accessibilityLabel("Play the sound that simulates the clicking feedback of objects that are at a medium distance.")
//                                .fontWeight(.regular)
//                                .foregroundStyle(.white)
//                                .frame(width: 176, height: 64)
//                                .accessibilitySortPriority(6)
//                                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
//                                .accessibilitySortPriority(2)
//                                .accessibilityFocused($announce6)
//                                .onAppear(){
//                                    announce6 = false
//                                }
//                        })
//                        
//                        HStack{}.frame(width: 8)
//                        Button(action: {
//                            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
//                                audioPlayerFar.prepareToPlay()
//                                audioPlayerFar.play()
//                            }
//                            
//                        }, label: {
//                            Text("Far")
////                                .accessibilityLabel("Play the sound that simulates the clicking feedback of objects that are far away.")
//                                .fontWeight(.regular)
//                                .foregroundStyle(.white)
//                                .frame(width: 176, height: 64)
//                                .accessibilitySortPriority(6)
//                                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 10, style: .continuous))
//                                .accessibilitySortPriority(1)
//                                .accessibilityFocused($announce7)
//                                .onAppear(){
//                                    announce7 = false
//                                }
//                        })
//                    }
//                    
//                    //                    Text("You're entering the Augmented Reality Realm. \nJust hold your device and face its back camera anywhere \nto hear the coins' resonance from your sound.")
//                    //                        .accessibilityHidden(true)
//                    //                        .foregroundStyle(.white)
//                    //                        .multilineTextAlignment(.center)
//                    //                        .padding(.bottom, 8)
//                    //                        .padding(.top, 16)
//                    //                        .padding(.trailing, 16)
//                    //                        .padding(.leading, 16)
//                }
                
                Spacer()
                
            }
            .opacity(isVisible ? 1 : 0)
        }
        .navigationBarBackButtonHidden()
        .onAppear(){
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                withAnimation(.easeIn(duration: 0.5)){
                    isVisible = true
                }
            }
        }
        .navigationDestination(isPresented: $changeView) {
            ARView()
        }
    }
}

