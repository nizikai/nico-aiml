import SwiftUI
import SpriteKit
import AVFoundation

class StoryScene: SKScene{
    
    let blackNode = SKSpriteNode(imageNamed: "Black")
    let blueCircleNode = SKSpriteNode(imageNamed: "blueCircle")
    let redCircleNode = SKSpriteNode(imageNamed: "redCircle")
    let greenCircleNode = SKSpriteNode(imageNamed: "greenCircle")
    let grayCircleNode = SKSpriteNode(imageNamed: "grayCircle")
    let whiteLine = SKSpriteNode(imageNamed: "whiteLine")
    let glowLine = SKSpriteNode(imageNamed: "glowLine")
    let whiteSpark = SKSpriteNode(imageNamed: "whiteSparks")
    
    let redRing = SKSpriteNode(imageNamed: "redRing")
    let greenRing = SKSpriteNode(imageNamed: "greenRing")
    let blueRing = SKSpriteNode(imageNamed: "blueRing")
    
    let lightNode = SKLightNode()
    let lightNode2 = SKLightNode()
    
    let line1 = SKSpriteNode(imageNamed: "lineOne")
    let line2 = SKSpriteNode(imageNamed: "lineOne")
    let line3 = SKSpriteNode(imageNamed: "lineTwo")
    let line4 = SKSpriteNode(imageNamed: "lineOne")
    let line5 = SKSpriteNode(imageNamed: "lineOne")
    let line6 = SKSpriteNode(imageNamed: "lineTwo")
    let line7 = SKSpriteNode(imageNamed: "lineThree")
    let line8 = SKSpriteNode(imageNamed: "lineFive")
    let line9 = SKSpriteNode(imageNamed: "lineFour")
    let line10 = SKSpriteNode(imageNamed: "lineFive")
    let line11 = SKSpriteNode(imageNamed: "lineThree")
    let line12 = SKSpriteNode(imageNamed: "lineFour")
    let line13 = SKSpriteNode(imageNamed: "lineThree")
    let line14 = SKSpriteNode(imageNamed: "lineFour")
    let line15 = SKSpriteNode(imageNamed: "lineOne")
    let line16 = SKSpriteNode(imageNamed: "lineThree")
    let line17 = SKSpriteNode(imageNamed: "lineOne")
    let line18 = SKSpriteNode(imageNamed: "lineTwo")
    let line19 = SKSpriteNode(imageNamed: "lineOne")
    let line20 = SKSpriteNode(imageNamed: "lineOne")
    
    override func didMove(to view: SKView) {
        
        scene?.size = CGSize(width: 2160, height: 1620)
        scene?.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        scene?.backgroundColor = UIColor(.black)
        scene?.view?.allowsTransparency = true
        scene?.scaleMode = .aspectFill
        
        lightNode.falloff = 0
        lightNode.ambientColor = .white
        lightNode.lightColor = .white
        lightNode.categoryBitMask = 1
        lightNode.position = CGPoint(x: 1500, y: 0)
        self.addChild(lightNode)
        
        lightNode2.falloff = 1
        lightNode2.ambientColor = .white
        lightNode2.lightColor = .white
        lightNode2.categoryBitMask = 1
        lightNode2.alpha = 0
        lightNode2.position = CGPoint(x: 0, y: 0)
        self.addChild(lightNode2)
        
        blackNode.position = CGPoint(x: 0, y: 0)
        blackNode.size = CGSize(width: 750, height: 750)
        blackNode.setScale(10)
        blackNode.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        self.addChild(blackNode)
        
        redRing.position = CGPoint(x: 400, y: -200)
        redRing.size = CGSize(width: 500, height: 500)
        redRing.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        redRing.lightingBitMask = 1
        redRing.alpha = 0
        self.addChild(redRing)
        
        blueRing.position = CGPoint(x: -200, y: 300)
        blueRing.size = CGSize(width: 300, height: 300)
        blueRing.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        blueRing.zRotation = 272
        blueRing.lightingBitMask = 1
        blueRing.alpha = 0
        self.addChild(blueRing)
        
        greenRing.position = CGPoint(x: -400, y: -400)
        greenRing.size = CGSize(width: 750, height: 750)
        greenRing.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        greenRing.lightingBitMask = 1
        greenRing.alpha = 0
        self.addChild(greenRing)
        
        blueCircleNode.position = CGPoint(x: 0, y: 854)
        blueCircleNode.size = CGSize(width: 1500, height: 1500)
        blueCircleNode.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        blueCircleNode.lightingBitMask = 1
        blueCircleNode.alpha = 0
        blueCircleNode.blendMode = SKBlendMode.screen
        self.addChild(blueCircleNode)
        
        redCircleNode.position = CGPoint(x: -828, y: -737)
        redCircleNode.size = CGSize(width: 1500, height: 1500)
        redCircleNode.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        redCircleNode.lightingBitMask = 1
        redCircleNode.alpha = 0
        redCircleNode.blendMode = SKBlendMode.screen
        self.addChild(redCircleNode)
        
        greenCircleNode.position = CGPoint(x: 820, y: -737)
        greenCircleNode.size = CGSize(width: 1500, height: 1500)
        greenCircleNode.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        greenCircleNode.lightingBitMask = 1
        greenCircleNode.alpha = 0
        greenCircleNode.blendMode = SKBlendMode.screen
        self.addChild(greenCircleNode)
        
        whiteSpark.position = CGPoint(x: 0, y: 0)
        whiteSpark.size = CGSize(width: 1500, height: 1500)
        whiteSpark.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        whiteSpark.lightingBitMask = 1
        whiteSpark.alpha = 0
        whiteSpark.blendMode = SKBlendMode.screen
        self.addChild(whiteSpark)
        
        grayCircleNode.position = CGPoint(x: 0, y: 0)
        grayCircleNode.size = CGSize(width: 7000, height: 7000)
        grayCircleNode.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        grayCircleNode.lightingBitMask = 1
        grayCircleNode.alpha = 1
        grayCircleNode.blendMode = SKBlendMode.screen
        self.addChild(grayCircleNode)
        
        line1.position = CGPoint(x: -500, y: 0)
        line1.size = CGSize(width: 80, height: 300)
        line1.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line1.lightingBitMask = 1
        line1.alpha = 0
        line1.blendMode = SKBlendMode.screen
        self.addChild(line1)
        
        line2.position = CGPoint(x: -450, y: 0)
        line2.size = CGSize(width: 80, height: 300)
        line2.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line2.lightingBitMask = 1
        line2.alpha = 0
        line2.blendMode = SKBlendMode.screen
        self.addChild(line2)
        
        line3.position = CGPoint(x: -400, y: 0)
        line2.size = CGSize(width: 80, height: 300)
        line3.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line3.lightingBitMask = 1
        line3.alpha = 0
        line3.blendMode = SKBlendMode.screen
        self.addChild(line3)
        
        line4.position = CGPoint(x: -350, y: 0)
        line4.size = CGSize(width: 80, height: 300)
        line4.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line4.lightingBitMask = 1
        line4.alpha = 0
        line4.blendMode = SKBlendMode.screen
        self.addChild(line4)
        
        line5.position = CGPoint(x: -300, y: 0)
        line5.size = CGSize(width: 80, height: 300)
        line5.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line5.lightingBitMask = 1
        line5.alpha = 0
        line5.blendMode = SKBlendMode.screen
        self.addChild(line5)
        
        line6.position = CGPoint(x: -250, y: 0)
        line6.size = CGSize(width: 80, height: 300)
        line6.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line6.lightingBitMask = 1
        line6.alpha = 0
        line6.blendMode = SKBlendMode.screen
        self.addChild(line6)
        
        line7.position = CGPoint(x: -200, y: 0)
        line7.size = CGSize(width: 80, height: 300)
        line7.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line7.lightingBitMask = 1
        line7.alpha = 0
        line7.blendMode = SKBlendMode.screen
        self.addChild(line7)
        
        line8.position = CGPoint(x: -150, y: 0)
        line8.size = CGSize(width: 80, height: 300)
        line8.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line8.lightingBitMask = 1
        line8.alpha = 0
        line8.blendMode = SKBlendMode.screen
        self.addChild(line8)
        
        line9.position = CGPoint(x: -100, y: 0)
        line9.size = CGSize(width: 80, height: 300)
        line9.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line9.lightingBitMask = 1
        line9.alpha = 0
        line9.blendMode = SKBlendMode.screen
        self.addChild(line9)
        
        line10.position = CGPoint(x: -50, y: 0)
        line10.size = CGSize(width: 80, height: 300)
        line10.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line10.lightingBitMask = 1
        line10.alpha = 0
        line10.blendMode = SKBlendMode.screen
        self.addChild(line10)
        
        line11.position = CGPoint(x: 0, y: 0)
        line11.size = CGSize(width: 80, height: 300)
        line11.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line11.lightingBitMask = 1
        line11.alpha = 0
        line11.blendMode = SKBlendMode.screen
        self.addChild(line11)
        
        line12.position = CGPoint(x: 50, y: 0)
        line12.size = CGSize(width: 80, height: 300)
        line12.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line12.lightingBitMask = 1
        line12.alpha = 0
        line12.blendMode = SKBlendMode.screen
        self.addChild(line12)
        
        line13.position = CGPoint(x: 100, y: 0)
        line13.size = CGSize(width: 80, height: 300)
        line13.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line13.lightingBitMask = 1
        line13.alpha = 0
        line13.blendMode = SKBlendMode.screen
        self.addChild(line13)
        
        line14.position = CGPoint(x: 150, y: 0)
        line14.size = CGSize(width: 80, height: 300)
        line14.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line14.lightingBitMask = 1
        line14.alpha = 0
        line14.blendMode = SKBlendMode.screen
        self.addChild(line14)
        
        line15.position = CGPoint(x: 200, y: 0)
        line15.size = CGSize(width: 80, height: 300)
        line15.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line15.lightingBitMask = 1
        line15.alpha = 0
        line15.blendMode = SKBlendMode.screen
        self.addChild(line15)
        
        line16.position = CGPoint(x: 250, y: 0)
        line16.size = CGSize(width: 80, height: 300)
        line16.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line16.lightingBitMask = 1
        line16.alpha = 0
        line16.blendMode = SKBlendMode.screen
        self.addChild(line16)
        
        line17.position = CGPoint(x: 300, y: 0)
        line17.size = CGSize(width: 80, height: 300)
        line17.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line17.lightingBitMask = 1
        line17.alpha = 0
        line17.blendMode = SKBlendMode.screen
        self.addChild(line17)
        
        line18.position = CGPoint(x: 350, y: 0)
        line18.size = CGSize(width: 80, height: 300)
        line18.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line18.lightingBitMask = 1
        line18.alpha = 0
        line18.blendMode = SKBlendMode.screen
        self.addChild(line18)
        
        line19.position = CGPoint(x: 400, y: 0)
        line19.size = CGSize(width: 80, height: 300)
        line19.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line19.lightingBitMask = 1
        line19.alpha = 0
        line19.blendMode = SKBlendMode.screen
        self.addChild(line19)
        
        line20.position = CGPoint(x: 450, y: 0)
        line20.size = CGSize(width: 80, height: 300)
        line20.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        line20.lightingBitMask = 1
        line20.alpha = 0
        line20.blendMode = SKBlendMode.screen
        self.addChild(line20)
        
        whiteLine.position = CGPoint(x: 0, y: 0)
        whiteLine.size = CGSize(width: 1500, height: 1500)
        whiteLine.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        whiteLine.lightingBitMask = 1
        whiteLine.alpha = 0
        whiteLine.blendMode = SKBlendMode.screen
        self.addChild(whiteLine)
        
        glowLine.position = CGPoint(x: 0, y: 0)
        glowLine.size = CGSize(width: 1500, height: 1500)
        glowLine.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        glowLine.lightingBitMask = 1
        glowLine.alpha = 0
        glowLine.blendMode = SKBlendMode.screen
        self.addChild(glowLine)
        
        let appear = SKAction.fadeAlpha(to: 1, duration: 0.1)
        let emerge = SKAction.fadeAlpha(by: 1, duration: 0.5)
        let moveForward = SKAction.move(by: CGVector(dx: 3000, dy: 0), duration: 4)
        let moveBackward = SKAction.move(by: CGVector(dx: -3000, dy: 0), duration: 6)
        let moveToCentre = SKAction.move(to: CGPoint(x: 0, y: 0), duration: 1)
        let scaleZero = SKAction.scale(to: 0, duration: 2)
        let scaleZero2 = SKAction.scale(to: 0, duration: 0.5)
        let disappear = SKAction.fadeAlpha(to: 0, duration: 0.1)
        let fadeOut = SKAction.fadeAlpha(to: 0, duration: 1)
        let scaleFull = SKAction.scale(to: 10, duration: 5)
        let scaleHalf = SKAction.scale(by: 1.5, duration: 1)
        
        let wait5 = SKAction.wait(forDuration: 5)
        let wait3 = SKAction.wait(forDuration: 3)
        let wait1 = SKAction.wait(forDuration: 1)
        
        let rotateAction = SKAction.rotate(byAngle: 2 * Double.pi, duration: 10)
        let rotateForever = SKAction.repeatForever(rotateAction)
        
        redCircleNode.run(rotateForever)
        greenCircleNode.run(rotateForever)
        blueCircleNode.run(rotateForever)
        
        moveToCentre.timingMode = .easeInEaseOut
        scaleZero.timingMode = .easeInEaseOut
        scaleFull.timingMode = .easeOut
        
        whiteLine.run(wait1){
            self.whiteLine.run(emerge){
                self.lightNode.run(moveBackward){
                    self.redCircleNode.run(emerge){
                        self.greenCircleNode.run(emerge){
                            self.blueCircleNode.run(emerge)
                            self.lightNode.run(moveForward){
                                self.blueCircleNode.run(moveToCentre)
                                self.blueCircleNode.run(fadeOut)
                                self.redCircleNode.run(moveToCentre)
                                self.redCircleNode.run(fadeOut)
                                self.greenCircleNode.run(moveToCentre)
                                self.greenCircleNode.run(fadeOut)
                                self.grayCircleNode.run(scaleZero2)
                                self.line1.run(disappear)
                                self.line20.run(disappear){
                                    self.line2.run(disappear)
                                    self.line19.run(disappear){
                                        self.line3.run(disappear)
                                        self.line18.run(disappear){
                                            self.whiteSpark.run(emerge)
                                            self.line4.run(disappear)
                                            self.line17.run(disappear){
                                                self.glowLine.run(emerge)
                                                self.lightNode2.run(emerge)
                                                self.line5.run(disappear)
                                                self.line16.run(disappear){
                                                    self.line6.run(disappear)
                                                    self.line15.run(disappear){
                                                        self.line7.run(disappear)
                                                        self.line14.run(disappear){
                                                            self.line8.run(disappear)
                                                            self.line13.run(disappear){
                                                                self.line9.run(disappear)
                                                                self.line12.run(disappear){
                                                                    self.line10.run(disappear)
                                                                    self.line11.run(disappear)
                                                                    
                                                                    self.whiteLine.run(disappear)
                                                                    self.grayCircleNode.run(scaleFull)
                                                                    self.glowLine.run(disappear)
                                                                    self.whiteSpark.run(scaleHalf)
                                                                    
                                                                    self.whiteSpark.run(wait1){
                                                                        self.whiteSpark.run(scaleFull)
                                                                        self.greenRing.run(emerge)
                                                                        self.blueRing.run(emerge)
                                                                        self.redRing.run(emerge){
                                                                            self.redRing.run(wait1){
                                                                                self.redRing.run(fadeOut)
                                                                                self.blueRing.run(fadeOut)
                                                                                self.greenRing.run(fadeOut)
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        
        
        line1.run(wait5){
            self.line1.run(wait3){
                self.line1.run(appear){
                    self.line2.run(appear){
                        self.line3.run(appear){
                            self.line4.run(appear){
                                self.line5.run(appear){
                                    self.line6.run(appear){
                                        self.line7.run(appear){
                                            self.line8.run(appear){
                                                self.line9.run(appear){
                                                    self.line10.run(appear){
                                                        self.line11.run(appear){
                                                            self.line12.run(appear){
                                                                self.line13.run(appear){
                                                                    self.line14.run(appear){
                                                                        self.line15.run(appear){
                                                                            self.line16.run(appear){
                                                                                self.line17.run(appear){
                                                                                    self.line18.run(appear){
                                                                                        self.line19.run(appear){
                                                                                            self.line20.run(appear)
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

struct StoryView: View {
    
    @State var scene: StoryScene
    @State var isVisible: Bool = false
    @State var changeView: Bool = false
    
    @State var showCaption2: Bool = false
    @State var showCaption3: Bool = false
    @State var showCaption4: Bool = false
    @State var showCaption5: Bool = false
    @State var showCaption6: Bool = false
    
    var audioPlayer = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "Story", withExtension: "mp3")!)
    
    var body: some View {
        
        ZStack{
            
            SpriteView(scene: scene, preferredFramesPerSecond: 60)
                .ignoresSafeArea()
                .accessibilityLabel("Three Rings: Red, Green, Blue")
            
            VStack{
                Spacer()
                Text(showCaption6 ? "This realm needs your help to retrieve the lost Coins." : showCaption5 ? "The Coins are scattered." : showCaption4 ? "But one day, The String broke." : showCaption3 ? ".. tied together by the String of Resonance." : showCaption2 ? "In this realm, it exists of 3 Enormous Chroma Coins, the Red, Green, and Blue.." : "People say that light is a combination of multiple colours")
                    .font(.body)
                    .fontWeight(.semibold)
                    .foregroundStyle(.white)
                    .shadow(color: .white, radius: 1)
                    .padding()
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                    .accessibilityHidden(true)
                
                VStack{}
                    .padding(.top, 32)
            }
            .opacity(isVisible ? 1 : 0)
            
        }
        .onAppear(){
            audioPlayer.setVolume(0.5, fadeDuration: 2.5)
            audioPlayer.play()
            
            //was 20.5
            DispatchQueue.main.asyncAfter(deadline: .now() + 20.5) {
                changeView = true
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 19.5) {
                withAnimation(.easeIn(duration: 0.5)){
                    isVisible = false
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                withAnimation(.easeIn(duration: 0.5)){
                    isVisible = true
                }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                showCaption2 = true
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 8.5) {
                showCaption3 = true
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 11) {
                showCaption4 = true
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 14) {
                showCaption5 = true
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 15.5) {
                showCaption6 = true
            }
        }
        .onDisappear(){
            audioPlayer.stop()
        }
        .navigationDestination(isPresented: $changeView) {
            GuideView()
        }
        .navigationBarBackButtonHidden()
    }
}

#Preview {
    StoryView(scene: StoryScene())
}

