import Foundation
import AVFoundation
import SoundAnalysis

class AudioStreamManager {
    
    var engine: AVAudioEngine
    var streamAnalyzer: SNAudioStreamAnalyzer
    var inputFormat: AVAudioFormat
    var inputBus: AVAudioNodeBus
    
    var observer = AudioStreamObserver()
    var classificationRequest: SNClassifySoundRequest?
    
    let analysisQueue = DispatchQueue(label: "nizikai.AnalysisQueue")
    
    init(){
        engine = AVAudioEngine()
        inputBus = AVAudioNodeBus(0)
        inputFormat = engine.inputNode.inputFormat(forBus: inputBus)
        streamAnalyzer = SNAudioStreamAnalyzer(format: inputFormat)
        modelSetup()
        startAudioEngine()
    }
    
    func modelSetup(){
        let config = MLModelConfiguration()
        let soundClassifier = try? Model(configuration: config)
        guard let soundClassifier else {
            print("Model not found")
            return
        }
        classificationRequest = try? SNClassifySoundRequest(mlModel: soundClassifier.model)
    }
    
    func startAudioEngine() {
        do {
            try engine.start()
        } catch {
            print("Unable to start engine")
        }
    }
    
    func startAudioAnalyzer(with observer: SNResultsObserving){

            do{
                try streamAnalyzer.add(classificationRequest!,
                                       withObserver: observer)
            } catch{
                print("Cant analyze the observer")
            }
    }
    
    func installAudioTap() {
        engine.inputNode.installTap(onBus: inputBus,
                                    bufferSize: 8129,
                                    format: inputFormat,
                                    block: analyzeAudio(buffer:at:))
    }
    
    func removeAudioTap(){
        engine.inputNode.removeTap(onBus: inputBus)
    }
    
    func analyzeAudio(buffer: AVAudioBuffer, at time: AVAudioTime) {
        analysisQueue.async {
            self.streamAnalyzer.analyze(buffer,
                                        atAudioFramePosition: time.sampleTime)
        }
    }
}
