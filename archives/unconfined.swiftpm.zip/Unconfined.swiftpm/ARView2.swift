import SwiftUI
import ARKit
import AVFoundation


import SwiftUI

struct ARView2: View {
    private var streamManager = AudioStreamManager()
    @State var tapCounter = 1
    @State var changeView = false
    
    @AccessibilityFocusState var tapFocus1: Bool
    @AccessibilityFocusState var tapFocus2: Bool
    @AccessibilityFocusState var tapFocus3: Bool
    @AccessibilityFocusState var tapFocus4: Bool
    
    var audioPlayer = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "Captured", withExtension: "mp3")!)
    
    var body: some View {
        ZStack{
            ARSceneView2()
                .ignoresSafeArea()
            
            VStack{
                Spacer()
                HStack{
                    HStack{}
                        .padding(.leading, 64)
                    if(tapCounter == 1){
                        Text("Click your tongue and observe the resonance of the next Coin.\n")
                            .font(.headline)
                            .fontWeight(.semibold)
                            .foregroundStyle(.white)
                            .shadow(color: .white, radius: 1)
                            .padding()
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/))
                            .onAppear {
                                tapFocus1 = true
                            }
                            .accessibilityFocused($tapFocus1)
                            .accessibilitySortPriority(2)
                    }
                    if(tapCounter == 2){
                        Text("Red Coin found!\nLocated 5 meters away. Tap Next to Capture")
                            .font(.headline)
                            .fontWeight(.semibold)
                            .foregroundStyle(.white)
                            .shadow(color: .white, radius: 1)
                            .padding()
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/))
                            .onAppear {
                                tapFocus2 = true
                            }
                            .accessibilityFocused($tapFocus2)
                            .accessibilitySortPriority(2)
                    }
                    if(tapCounter == 3){
                        Text("Great! Since we've captured two Coins,\nfinding the next one is easier.")
                            .font(.headline)
                            .fontWeight(.semibold)
                            .foregroundStyle(.white)
                            .shadow(color: .white, radius: 1)
                            .padding()
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/))
                            .onAppear {
                                tapFocus3 = true
                                audioPlayer.setVolume(0.5, fadeDuration: 1)
                                audioPlayer.play()
                            }
                            .accessibilityFocused($tapFocus3)
                            .accessibilitySortPriority(2)
                    }
                    Spacer()
                    Button(action: {
                        withAnimation(.easeIn(duration: 0.5)){
                            tapCounter += 1
                            if(tapCounter == 4){
                                changeView = true
                            }
                        }
                    }, label: {
                        if(tapCounter == 3){
                            Text("Continue")
                                .font(.headline)
                                .fontWeight(.bold)
                                .foregroundStyle(.black)
                                .frame(width: 144, height: 64)
                                .accessibilitySortPriority(1)
                                .background(RoundedRectangle(cornerRadius: 10).fill(Color(.white)).shadow(color: .white, radius: 7))
                        }
                        else{
                            if(tapCounter <= 3){
                                Text("Next")
                                    .font(.headline)
                                    .fontWeight(.bold)
                                    .foregroundStyle(.black)
                                    .frame(width: 144, height: 64)
                                    .accessibilitySortPriority(1)
                                    .background(RoundedRectangle(cornerRadius: 10).fill(Color(.white)).shadow(color: .white, radius: 7))
                            }
                        }
                    })
                    .accessibilitySortPriority(1)
                    HStack{}
                        .padding(.trailing, 64)
                }
                VStack{}
                    .padding(.top, 64)
            }
        }
        .navigationDestination(isPresented: $changeView) {
            ARView3()
        }
        .navigationBarBackButtonHidden()
        .onDisappear(){
            streamManager.removeAudioTap()
        }
    }
}

struct ARSceneView2: UIViewRepresentable {
    
    private var streamManager: AudioStreamManager
    @ObservedObject var observer: AudioStreamObserver
    
    init() {
        observer = AudioStreamObserver()
        streamManager = AudioStreamManager()
        streamManager.startAudioAnalyzer(with: observer)
    }
    
    private let domeNode: SCNNode = {
        let node = SCNNode(geometry: SCNSphere(radius: 5))
        node.geometry?.firstMaterial?.diffuse.contents = UIColor.black.withAlphaComponent(0.95)
        node.geometry?.firstMaterial?.isDoubleSided = true
        return node
    }()
    
    private let redNode: SCNNode = {
        let node = SCNNode(geometry: SCNPlane(width: 1, height: 1))
        node.geometry?.firstMaterial?.diffuse.contents = #imageLiteral(resourceName: "redCircle")
        node.geometry?.firstMaterial?.isDoubleSided = true
        node.position = SCNVector3(x: -3, y: 0, z: -3)
        node.rotation = SCNVector4(0, 1, 0, Double.pi / 4)
        return node
    }()
    
    private let redNodeA: SCNNode = {
        let node = SCNNode(geometry: SCNPlane(width: 2, height: 2))
        node.geometry?.firstMaterial?.diffuse.contents = #imageLiteral(resourceName: "whiteCircle")
        node.geometry?.firstMaterial?.isDoubleSided = true
        node.position = SCNVector3(x: -3, y: 0, z: -3.01)
        node.rotation = SCNVector4(0, 1, 0, Double.pi / 4)
        node.scale = SCNVector3(x: 0, y: 0, z: 0)
        return node
    }()
    
    private let redNodeB: SCNNode = {
        let node = SCNNode(geometry: SCNPlane(width: 2, height: 2))
        node.geometry?.firstMaterial?.diffuse.contents = #imageLiteral(resourceName: "whiteCircle")
        node.geometry?.firstMaterial?.isDoubleSided = true
        node.position = SCNVector3(x: -3, y: 0, z: -3.02)
        node.rotation = SCNVector4(0, 1, 0, Double.pi / 4)
        node.scale = SCNVector3(x: 0, y: 0, z: 0)
        return node
    }()
    
    private let redNodeC: SCNNode = {
        let node = SCNNode(geometry: SCNPlane(width: 2, height: 2))
        node.geometry?.firstMaterial?.diffuse.contents = #imageLiteral(resourceName: "whiteCircle")
        node.geometry?.firstMaterial?.isDoubleSided = true
        node.position = SCNVector3(x: -3, y: 0, z: -3.03)
        node.rotation = SCNVector4(0, 1, 0, Double.pi / 4)
        node.scale = SCNVector3(x: 0, y: 0, z: 0)
        return node
    }()
    
    private let positionNode: SCNNode = {
        let node = SCNNode(geometry: SCNSphere(radius: 0))
        node.position = SCNVector3(x: -3, y: 0, z: -5)
        return node
    }()
    
    func makeUIView(context: Context) -> ARSCNView {
        
        let view = ARSCNView()
        
        // Start AR session
        let session = view.session
        let config = ARWorldTrackingConfiguration()
        session.run(config)
        
        //        view.debugOptions = [ARSCNDebugOptions.showWorldOrigin, ARSCNDebugOptions.showFeaturePoints]
        view.preferredFramesPerSecond = 60
        //        view.showsStatistics = true
        view.autoenablesDefaultLighting = true
        
        view.isOpaque = false
        
        
        view.scene.rootNode.addChildNode(positionNode)
        
        view.scene.rootNode.addChildNode(domeNode)
        view.scene.rootNode.addChildNode(redNode)
        view.scene.rootNode.addChildNode(redNodeA)
        view.scene.rootNode.addChildNode(redNodeB)
        view.scene.rootNode.addChildNode(redNodeC)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            streamManager.installAudioTap()
        }
        return view
    }
    
    func updateUIView(_ view: ARSCNView, context: Context) {
        
        //        for node in view.scene.rootNode.childNodes {
        //            node.removeFromParentNode()
        //        }
        var lastSound: String?
        let scaleUp = SCNAction.scale(to: 3, duration: 0.5)
        let scaleDown = SCNAction.scale(to: 0, duration: 0.5)
        
        let audioSources = SCNAudioSource(fileNamed: "Half.mp3")!
        audioSources.volume = 1
        audioSources.isPositional = true
        audioSources.shouldStream = false
        audioSources.load()
        
        let audioPlayer = SCNAudioPlayer(source: audioSources)
        
        scaleUp.timingMode = .easeOut
        
//        if observer.latestSound != "Clicks"{
//            notRecognized = true
//        }
//        if observer.latestSound != "Mushy Clicks"{
//            notRecognized = true
//        }
//        if observer.latestSound == "Clicks" || observer.latestSound == "Mushy Clicks" {
//            if notRecognized!{
//
//                    positionNode.addAudioPlayer(audioPlayer)
//                notRecognized = false
        
        if observer.latestSound == "Clicks" || observer.latestSound == "Mushy Clicks" {
            if lastSound != "Clicks" && lastSound != "Mushy Clicks" {
                positionNode.addAudioPlayer(audioPlayer)
                
                redNodeA.runAction(scaleUp){
                    redNodeB.runAction(scaleUp){
                        redNodeA.runAction(scaleDown)
                        redNodeC.runAction(scaleUp){
                            redNodeB.runAction(scaleDown){
                                redNodeC.runAction(scaleDown)
                            }
                        }
                    }
                }
                lastSound = observer.latestSound
            }
        }

        }
}
