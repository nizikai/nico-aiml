import Foundation
import SoundAnalysis

class AudioStreamObserver: NSObject, SNResultsObserving, ObservableObject {
    @Published var latestSound: String = ""
    
    func request(_ request: SNRequest, didProduce result: SNResult) {
        guard let result = result as? SNClassificationResult else {
            return print("Classification result empty")
        }
        if let topResult = result.classifications.first{
            DispatchQueue.main.async {
                self.latestSound = String(topResult.identifier)
                print(self.latestSound)
            }
        }
    }
}
