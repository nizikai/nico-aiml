import SwiftUI
import ARKit
import AVFoundation

struct ARView: View{
    
    private var streamManager = AudioStreamManager()
    @State var tapCounter = 1
    @State var changeView = false
    
    @AccessibilityFocusState var tapFocus1: Bool
    @AccessibilityFocusState var tapFocus2: Bool
    @AccessibilityFocusState var tapFocus3: Bool
    @AccessibilityFocusState var tapFocus4: Bool
    @AccessibilityFocusState var tapFocus5: Bool
    @AccessibilityFocusState var tapFocus6: Bool
    
    var audioPlayer = try! AVAudioPlayer(contentsOf: Bundle.main.url(forResource: "Captured", withExtension: "mp3")!)
    
    var body: some View {
        ZStack{
            ARSceneView()
                .ignoresSafeArea()
            
            VStack{
                Spacer()
                HStack{
                    HStack{}
                        .padding(.leading, 64)
                    if(tapCounter == 1){
                        Text("In this realm, sound travels more slowly, making it easier to discern the locations of objects.\nTry clicking your tongue multiple times to hear the feedback from The Coin.")
                            .font(.headline)
                            .fontWeight(.semibold)
                            .foregroundStyle(.white)
                            .shadow(color: .white, radius: 1)
                            .padding()
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/))
                            .onAppear {
                                tapFocus1 = true
                            }
                            .accessibilityFocused($tapFocus1)
                            .accessibilitySortPriority(2)
                    }
                    if(tapCounter == 2){
                        Text("The sound has some reverb, indicating that it resonates far ahead.\nGreat! The Blue Coin has been located 10 meters away.")
                            .font(.headline)
                            .fontWeight(.semibold)
                            .foregroundStyle(.white)
                            .shadow(color: .white, radius: 1)
                            .padding()
                            .accessibilityIdentifier("ARView2")
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/))
                            .onAppear {
                                tapFocus2 = true
                            }
                            .accessibilityFocused($tapFocus2)
                            .accessibilitySortPriority(2)
                    }
                    if(tapCounter == 3){
                        Text("Capture the Blue Coin now.\nTap Next to Capture.")
                            .font(.headline)
                            .fontWeight(.semibold)
                            .foregroundStyle(.white)
                            .shadow(color: .white, radius: 1)
                            .padding()
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/))
                            .onAppear {
                                tapFocus3 = true
                            }
                            .accessibilityFocused($tapFocus3)
                            .accessibilitySortPriority(2)
                    }
                    if(tapCounter == 4){
                        Text("Good job! Blue Coin captured!\nNow to the next Coins.")
                            .font(.headline)
                            .fontWeight(.semibold)
                            .foregroundStyle(.white)
                            .shadow(color: .white, radius: 1)
                            .padding()
                            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/))
                            .onAppear {
                                tapFocus4 = true
                                audioPlayer.setVolume(0.5, fadeDuration: 1)
                                audioPlayer.play()
                            }
                            .accessibilityFocused($tapFocus4)
                            .accessibilitySortPriority(2)
                    }
                    Spacer()
                    Button(action: {
                        withAnimation(.easeIn(duration: 0.5)){
                            tapCounter += 1
                            if(tapCounter == 5){
                                changeView = true
                            }
                        }
                    }, label: {
                        if(tapCounter == 4){
                            Text("Continue")
                                .font(.headline)
                                .fontWeight(.bold)
                                .foregroundStyle(.black)
                                .frame(width: 144, height: 64)
                                .accessibilitySortPriority(1)
                                .background(RoundedRectangle(cornerRadius: 10).fill(Color(.white)).shadow(color: .white, radius: 7))
                        }
                        else{
                            if(tapCounter <= 4){
                                Text("Next")
                                    .font(.headline)
                                    .fontWeight(.bold)
                                    .foregroundStyle(.black)
                                    .frame(width: 144, height: 64)
                                    .accessibilitySortPriority(1)
                                    .background(RoundedRectangle(cornerRadius: 10).fill(Color(.white)).shadow(color: .white, radius: 7))
                            }
                        }
                    })
                    .accessibilitySortPriority(1)
                    HStack{}
                        .padding(.trailing, 64)
                }
                VStack{}
                    .padding(.top, 64)
            }
        }
        .navigationDestination(isPresented: $changeView) {
            ARView2()
        }
        .navigationBarBackButtonHidden()
    }
}

struct ARSceneView: UIViewRepresentable {
    
    private var streamManager: AudioStreamManager
    @ObservedObject var observer: AudioStreamObserver
    
    init() {
        observer = AudioStreamObserver()
        streamManager = AudioStreamManager()
        streamManager.startAudioAnalyzer(with: observer)
    }
    
    private let domeNode: SCNNode = {
        let node = SCNNode(geometry: SCNSphere(radius: 5))
        node.geometry?.firstMaterial?.diffuse.contents = UIColor.black.withAlphaComponent(0.95)
        node.geometry?.firstMaterial?.isDoubleSided = true
        return node
    }()
    
    private let blueNode: SCNNode = {
        let node = SCNNode(geometry: SCNPlane(width: 1, height: 1))
        node.geometry?.firstMaterial?.diffuse.contents = #imageLiteral(resourceName: "blueCircle")
        node.geometry?.firstMaterial?.isDoubleSided = true
        node.position = SCNVector3(x: 0, y: 0, z: -3)
        return node
    }()
    
    private let blueNodeA: SCNNode = {
        let node = SCNNode(geometry: SCNPlane(width: 2, height: 2))
        node.geometry?.firstMaterial?.diffuse.contents = #imageLiteral(resourceName: "whiteCircle")
        node.geometry?.firstMaterial?.isDoubleSided = true
        node.position = SCNVector3(x: 0, y: 0, z: -3.01)
        node.scale = SCNVector3(x: 0, y: 0, z: 0)
        return node
    }()
    
    private let blueNodeB: SCNNode = {
        let node = SCNNode(geometry: SCNPlane(width: 2, height: 2))
        node.geometry?.firstMaterial?.diffuse.contents = #imageLiteral(resourceName: "whiteCircle")
        node.geometry?.firstMaterial?.isDoubleSided = true
        node.position = SCNVector3(x: 0, y: 0, z: -3.02)
        node.scale = SCNVector3(x: 0, y: 0, z: 0)
        return node
    }()
    
    private let blueNodeC: SCNNode = {
        let node = SCNNode(geometry: SCNPlane(width: 2, height: 2))
        node.geometry?.firstMaterial?.diffuse.contents = #imageLiteral(resourceName: "whiteCircle")
        node.geometry?.firstMaterial?.isDoubleSided = true
        node.position = SCNVector3(x: 0, y: 0, z: -3.03)
        node.scale = SCNVector3(x: 0, y: 0, z: 0)
        return node
    }()
    
    private let positionNode: SCNNode = {
        let node = SCNNode(geometry: SCNSphere(radius: 0))
        node.position = SCNVector3(x: 0, y: 0, z: -10)
        return node
    }()
    
    func makeUIView(context: Context) -> ARSCNView {
        
        let view = ARSCNView()
        
        // Start AR session
        let session = view.session
        let config = ARWorldTrackingConfiguration()
        session.run(config)
        
        //        view.debugOptions = [ARSCNDebugOptions.showWorldOrigin, ARSCNDebugOptions.showFeaturePoints]
        view.preferredFramesPerSecond = 60
        //        view.showsStatistics = true
        view.autoenablesDefaultLighting = true
        
        view.isOpaque = false
        
        
        view.scene.rootNode.addChildNode(positionNode)
        
        view.scene.rootNode.addChildNode(domeNode)
        view.scene.rootNode.addChildNode(blueNode)
        view.scene.rootNode.addChildNode(blueNodeA)
        view.scene.rootNode.addChildNode(blueNodeB)
        view.scene.rootNode.addChildNode(blueNodeC)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            streamManager.installAudioTap()
        }
        
        return view
    }
    
    func updateUIView(_ view: ARSCNView, context: Context) {
        
        //        for node in view.scene.rootNode.childNodes {
        //            node.removeFromParentNode()
        //        }
        var lastSound: String?
        let scaleUp = SCNAction.scale(to: 3, duration: 0.5)
        let scaleDown = SCNAction.scale(to: 0, duration: 0.5)
        
        let audioSources = SCNAudioSource(fileNamed: "Far.mp3")!
        audioSources.volume = 1
        audioSources.isPositional = true
        audioSources.shouldStream = false
        audioSources.load()
        
        let audioPlayer = SCNAudioPlayer(source: audioSources)
        
        scaleUp.timingMode = .easeOut
        
        //        if observer.latestSound != "Clicks"{
        //            notRecognized = true
        //        }
        //        if observer.latestSound != "Mushy Clicks"{
        //            notRecognized = true
        //        }
        //        if observer.latestSound == "Clicks" || observer.latestSound == "Mushy Clicks" {
        //            if notRecognized!{
        //
        //                    positionNode.addAudioPlayer(audioPlayer)
        //                notRecognized = false
        
        if observer.latestSound == "Clicks" || observer.latestSound == "Mushy Clicks" {
            if lastSound != "Clicks" && lastSound != "Mushy Clicks" {
                positionNode.addAudioPlayer(audioPlayer)
                
                blueNodeA.runAction(scaleUp){
                    blueNodeB.runAction(scaleUp){
                        blueNodeA.runAction(scaleDown)
                        blueNodeC.runAction(scaleUp){
                            blueNodeB.runAction(scaleDown){
                                blueNodeC.runAction(scaleDown)
                            }
                        }
                    }
                }
                lastSound = observer.latestSound
            }
        }
        
    }
}
