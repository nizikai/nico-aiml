import CoreMotion

class MotionData : ObservableObject {
    
    let motion = CMMotionManager()
    @Published var yaw : Double = 0.0
    @Published var roll : Double = 0.0
    @Published var pitch : Double = 0.0
    
    func getMotionData() {
        if motion.isDeviceMotionAvailable{
            //Updates 60 times per second
            self.motion.deviceMotionUpdateInterval = 1.0/90
            self.motion.startDeviceMotionUpdates(to: .main, withHandler: { (data, error) in
                if let acquiredData = data {
                    self.yaw = acquiredData.attitude.yaw
                    self.roll = acquiredData.attitude.roll
                    self.pitch = acquiredData.attitude.pitch
                    
                    print("yaw: " , self.yaw, "roll: " , self.roll, "pitch: " , self.pitch )
                }
            })
        }
        else{
            print("No device motion data avaiable.")
        }
    }
    
    func stopMotionData() {
        motion.stopDeviceMotionUpdates()
    }
}
